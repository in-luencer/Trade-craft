export const emailjsConfig = {
  serviceId: 'service_yv3z6qi',
  templateId: 'template_rdtzbw4',
  publicKey: '1IAdEEyqKlumQiOFc',
  templateParams: {
    from_name: 'Website Feedback',
    to_name: 'Admin',
    email: 'malanadaanil3@gmail.com',
    reply_to: 'malanadaanil3@gmail.com'
  }
}; 