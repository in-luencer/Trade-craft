"use client"

import type React from "react"

import { useState } from "react"
import { DndContext, type DragEndEvent, closestCenter } from "@dnd-kit/core"
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { ChevronDown, GripVertical, Plus, Save, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

import StrategyPreview from "./strategy-preview"

// Types for our strategy components
type IndicatorType = {
  id: string
  type: "indicator"
  name: string
  indicator: string
  period: number
}

type ConditionType = {
  id: string
  type: "condition"
  name: string
  leftOperand: string
  operator: string
  rightOperand: string
}

type EntryRuleType = {
  id: string
  type: "entry"
  name: string
  direction: "long" | "short"
  conditions: string[]
}

type ExitRuleType = {
  id: string
  type: "exit"
  name: string
  conditions: string[]
}

type StrategyComponentType = IndicatorType | ConditionType | EntryRuleType | ExitRuleType

// Sortable component wrapper
function SortableItem({
  id,
  children,
  onRemove,
}: {
  id: string
  children: React.ReactNode
  onRemove: (id: string) => void
}) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <div ref={setNodeRef} style={style} className="relative mb-4">
      <div className="absolute left-2 top-4 cursor-move" {...attributes} {...listeners}>
        <GripVertical className="h-5 w-5 text-muted-foreground" />
      </div>
      <Button variant="ghost" size="icon" className="absolute right-2 top-4" onClick={() => onRemove(id)}>
        <X className="h-4 w-4" />
      </Button>
      {children}
    </div>
  )
}

// Indicator component
function IndicatorComponent({ data }: { data: IndicatorType }) {
  return (
    <Card className="pl-8 pr-8">
      <CardHeader>
        <CardTitle className="text-lg">Indicator: {data.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Indicator Type</label>
              <Select defaultValue={data.indicator}>
                <SelectTrigger>
                  <SelectValue placeholder="Select indicator" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sma">Simple Moving Average (SMA)</SelectItem>
                  <SelectItem value="ema">Exponential Moving Average (EMA)</SelectItem>
                  <SelectItem value="rsi">Relative Strength Index (RSI)</SelectItem>
                  <SelectItem value="macd">MACD</SelectItem>
                  <SelectItem value="bollinger">Bollinger Bands</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Period</label>
              <Input type="number" defaultValue={data.period} />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Condition component
function ConditionComponent({ data }: { data: ConditionType }) {
  return (
    <Card className="pl-8 pr-8">
      <CardHeader>
        <CardTitle className="text-lg">Condition: {data.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Left Operand</label>
              <Select defaultValue={data.leftOperand}>
                <SelectTrigger>
                  <SelectValue placeholder="Select value" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="close">Close Price</SelectItem>
                  <SelectItem value="sma_20">SMA(20)</SelectItem>
                  <SelectItem value="ema_50">EMA(50)</SelectItem>
                  <SelectItem value="rsi_14">RSI(14)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Operator</label>
              <Select defaultValue={data.operator}>
                <SelectTrigger>
                  <SelectValue placeholder="Select operator" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="crosses_above">Crosses Above</SelectItem>
                  <SelectItem value="crosses_below">Crosses Below</SelectItem>
                  <SelectItem value="greater_than">Greater Than</SelectItem>
                  <SelectItem value="less_than">Less Than</SelectItem>
                  <SelectItem value="equals">Equals</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Right Operand</label>
              <Select defaultValue={data.rightOperand}>
                <SelectTrigger>
                  <SelectValue placeholder="Select value" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="close">Close Price</SelectItem>
                  <SelectItem value="sma_20">SMA(20)</SelectItem>
                  <SelectItem value="ema_50">EMA(50)</SelectItem>
                  <SelectItem value="rsi_14">RSI(14)</SelectItem>
                  <SelectItem value="70">70</SelectItem>
                  <SelectItem value="30">30</SelectItem>
                  <SelectItem value="0">0</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Entry Rule component
function EntryRuleComponent({ data }: { data: EntryRuleType }) {
  return (
    <Card className="pl-8 pr-8">
      <CardHeader>
        <CardTitle className="text-lg">Entry Rule: {data.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Direction</label>
              <Select defaultValue={data.direction}>
                <SelectTrigger>
                  <SelectValue placeholder="Select direction" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="long">Long</SelectItem>
                  <SelectItem value="short">Short</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Conditions</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select conditions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="condition1">RSI Oversold</SelectItem>
                  <SelectItem value="condition2">Price Above SMA</SelectItem>
                  <SelectItem value="condition3">MACD Crossover</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Exit Rule component
function ExitRuleComponent({ data }: { data: ExitRuleType }) {
  return (
    <Card className="pl-8 pr-8">
      <CardHeader>
        <CardTitle className="text-lg">Exit Rule: {data.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Conditions</label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select conditions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="condition1">RSI Overbought</SelectItem>
                <SelectItem value="condition2">Price Below SMA</SelectItem>
                <SelectItem value="condition3">Take Profit (10%)</SelectItem>
                <SelectItem value="condition4">Stop Loss (5%)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function StrategyBuilder() {
  const [activeTab, setActiveTab] = useState("builder")
  const [strategyName, setStrategyName] = useState("My Trading Strategy")
  const [strategyDescription, setStrategyDescription] = useState(
    "A simple trading strategy based on technical indicators",
  )
  const [components, setComponents] = useState<StrategyComponentType[]>([
    {
      id: "indicator-1",
      type: "indicator",
      name: "SMA 20",
      indicator: "sma",
      period: 20,
    },
    {
      id: "indicator-2",
      type: "indicator",
      name: "RSI 14",
      indicator: "rsi",
      period: 14,
    },
    {
      id: "condition-1",
      type: "condition",
      name: "RSI Oversold",
      leftOperand: "rsi_14",
      operator: "less_than",
      rightOperand: "30",
    },
    {
      id: "entry-1",
      type: "entry",
      name: "Long Entry",
      direction: "long",
      conditions: ["condition-1"],
    },
    {
      id: "exit-1",
      type: "exit",
      name: "Take Profit",
      conditions: [],
    },
  ])

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event

    if (over && active.id !== over.id) {
      setComponents((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over.id)
        return arrayMove(items, oldIndex, newIndex)
      })
    }
  }

  function addComponent(type: string) {
    const id = `${type}-${Date.now()}`
    let newComponent: StrategyComponentType

    switch (type) {
      case "indicator":
        newComponent = {
          id,
          type: "indicator",
          name: "New Indicator",
          indicator: "sma",
          period: 20,
        }
        break
      case "condition":
        newComponent = {
          id,
          type: "condition",
          name: "New Condition",
          leftOperand: "close",
          operator: "greater_than",
          rightOperand: "sma_20",
        }
        break
      case "entry":
        newComponent = {
          id,
          type: "entry",
          name: "New Entry Rule",
          direction: "long",
          conditions: [],
        }
        break
      case "exit":
        newComponent = {
          id,
          type: "exit",
          name: "New Exit Rule",
          conditions: [],
        }
        break
      default:
        return
    }

    setComponents([...components, newComponent])
  }

  function removeComponent(id: string) {
    setComponents(components.filter((component) => component.id !== id))
  }

  function saveStrategy() {
    // In a real app, this would save to your backend
    alert("Strategy saved successfully!")
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Strategy Details</CardTitle>
          <CardDescription>Define the basic information about your strategy</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Strategy Name</label>
              <Input
                value={strategyName}
                onChange={(e) => setStrategyName(e.target.value)}
                placeholder="Enter strategy name"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={strategyDescription}
                onChange={(e) => setStrategyDescription(e.target.value)}
                placeholder="Describe your strategy"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="builder">Builder</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>
        <TabsContent value="builder" className="space-y-4">
          <div className="flex justify-between">
            <h2 className="text-xl font-bold">Strategy Components</h2>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" /> Add Component
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => addComponent("indicator")}>Add Indicator</DropdownMenuItem>
                <DropdownMenuItem onClick={() => addComponent("condition")}>Add Condition</DropdownMenuItem>
                <DropdownMenuItem onClick={() => addComponent("entry")}>Add Entry Rule</DropdownMenuItem>
                <DropdownMenuItem onClick={() => addComponent("exit")}>Add Exit Rule</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={components.map((c) => c.id)} strategy={verticalListSortingStrategy}>
              {components.map((component) => (
                <SortableItem key={component.id} id={component.id} onRemove={removeComponent}>
                  {component.type === "indicator" && <IndicatorComponent data={component as IndicatorType} />}
                  {component.type === "condition" && <ConditionComponent data={component as ConditionType} />}
                  {component.type === "entry" && <EntryRuleComponent data={component as EntryRuleType} />}
                  {component.type === "exit" && <ExitRuleComponent data={component as ExitRuleType} />}
                </SortableItem>
              ))}
            </SortableContext>
          </DndContext>

          <Button className="mt-4" onClick={saveStrategy}>
            <Save className="mr-2 h-4 w-4" /> Save Strategy
          </Button>
        </TabsContent>
        <TabsContent value="preview">
          <StrategyPreview name={strategyName} description={strategyDescription} components={components} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
